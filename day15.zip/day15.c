#include <stdio.h>
#include <conio.h>

void main(){
    // que-1
    // int i,n;
    // printf("enter the number:");
    // scanf("%d",&n);
    // int arr[n];
    // printf("enter the array element:");
    // for(int i=0; i<n; i++){
    //     scanf("%d",&arr[i]);
    // }
    // for(int i=0; i<n; i++){
    //     printf("%d",arr[i]);
    // }
    // printf("\n");

    // que-2
    // int i,n,sum=0;
    // printf("enter the number:");
    // scanf("%d",&n);
    // int arr[n];
    // printf("enter the array element:");
    // for(int i=0; i<n; i++){
    //     scanf("%d",&arr[i]);
    // }
    // for(int i=0; i<n; i++){
    //     sum = sum + arr[i];
    // }
    // printf("sum of array:%d",sum);
    // printf("\n");

    // que-3
    // int i,n,sum=0;
    // printf("enter the number:");
    // scanf("%d",&n);
    // int arr[n];
    // printf("enter the array element:");
    // for(int i=0; i<n; i++){
    //     scanf("%d",&arr[i]);
    // }
    // for(int i=0; i<n; i++){
    //    if(i%2==0){
    //     sum = sum + arr[i];
    //    }
    // }
    // printf("sum of even number:%d",sum);
    // printf("\n");

    // que-4
    int i,n;
    int max,min;
    printf("enter the number:");
    scanf("%d",&n);
    int arr[n];
    printf("enter the array element:");
    for(int i=0; i<n; i++){
        scanf("%d",&arr[i]);
    }
    max = min = arr[0];
    for(i=1;i<n;i++){
        if(arr[i]>max){
           max = arr[i];
        }
    }
    printf("\n\n");
    for(i=1;i<n;i++){
        if(arr[i]<min){
           min = arr[i];
        }
    }
    printf("sum of maximum number:%d\n",max);
    printf("sum of minimum number:%d\n",min);
    printf("\n");
}