#include <stdio.h>
#include <conio.h>

void main(){
    // que-1 
    // for(int i=1; i<=5; i++){
    //     for(int j=i; j>=1; j--){
    //         printf("%d \t",j);
    //     }
    //     printf("\n");
    // }

    // que-2
    // for(int i=5; i>=1; i--){
    //     for(int j=5; j>=i; j--){
    //         printf("%d \t",j);
    //     }
    //     printf("\n");
    // }  

    // que-3
    // int n , i , j;
    // printf("enter the number:");
    // scanf("%d",&n);
    // for(i=n;i>=1;i--){
    //     for(j=1;j<=i;j++){
    //         printf("%d \t",i);    
    //     }        
    //     printf("\n");
    // }       

    // que-4
    // for(int i = 5; i >= 1; i--){
    //     for(int j = 1; j <= i; j++){
    //         printf("%d \t",j);
    //     }
    //     printf("\n");
    // }

    // que-5
    // int n , i , j;
    // printf("enter the number:");
    // scanf("%d",&n);
    // for(i=1;i<=n;i++){
    //     for(j=i;j<=n;j++){
    //         printf("%d \t",i);    
    //     }        
    //     printf("\n");
    // }

    // que-6 
    // for(int i = 5; i >= 1; i--){
    //     for(int j = 1; j <= i; j++){
    //         printf("%d \t",(j % 2) ? 1 : 0);
    //     }
    //     printf("\n");
    // }

    // que-7
    // for(char i='A'; i<='E'; i++){
    //     for(char j='A'; j<=i; j++){
    //         printf("%c\t",j);
    //     }
    //     printf("\n");
    // }

    // que-8
    // int num = 1;
    // for(int i = 1; i <= 5; i++){
    //     for(int j = 1; j <= i; j++){
    //         printf("%d\t", num++);
    //     }
    //     printf("\n");
    // }
}